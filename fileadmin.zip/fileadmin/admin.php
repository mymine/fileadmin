<?php
if (is_file($_SERVER['DOCUMENT_ROOT'] . '/360safe/360webscan.php')) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/360safe/360webscan.php';
}
// 注意文件路径
date_default_timezone_set('Asia/Shanghai');
$user = explode(':', $_SERVER['HTTP_HOST']);
$user = $user[0] . ':443';
$pass = date('Ym');
define('U', "admin");
define('P', "{$pass}");
?>